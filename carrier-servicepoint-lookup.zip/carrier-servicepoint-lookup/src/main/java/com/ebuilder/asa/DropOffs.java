package com.ebuilder.asa;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonSerialize(include = Inclusion.NON_NULL)
public class DropOffs{
   	private String lookupSRC;
   	private String exURL;   	
	private List<String> types;
   	private String mxRes;
   	private String matchCountry;
   	private String matchProvi;
   	private String matchCity;   	
   	private String matchZip;
   	private String type;
   	private String subType;   	
	private String site;
   	private Addr addr;
   	private Gps gps;
   	private String proxi;
   	private Contact contact;
   	private List<OpenHrs> openHrs;
   	
   	public String getExURL() {
		return exURL;
	}
	public void setExURL(String exURL) {
		this.exURL = exURL;
	}
   	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
 	public List<OpenHrs> getOpenHrs() {
		return openHrs;
	}
	public void setOpenHrs(List<OpenHrs> openHrs) {
		this.openHrs = openHrs;
	}
	public Contact getContact() {
		return contact;
	}
	public void setContact(Contact contact) {
		this.contact = contact;
	}
	public String getProxi() {
		return proxi;
	}
	public void setProxi(String proxi) {
		this.proxi = proxi;
	}
	public Gps getGps() {
		return gps;
	}
	public void setGps(Gps gps) {
		this.gps = gps;
	}
	public Addr getAddr() {
		return addr;
	}
	public void setAddr(Addr addr) {
		this.addr = addr;
	}
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getLookupSRC(){
		return this.lookupSRC;
	}
	public void setLookupSRC(String lookupSRC){
		this.lookupSRC = lookupSRC;
	}
 	public String getMatchCity(){
		return this.matchCity;
	}
	public void setMatchCity(String matchCity){
		this.matchCity = matchCity;
	}
 	public String getMatchCountry(){
		return this.matchCountry;
	}
	public void setMatchCountry(String matchCountry){
		this.matchCountry = matchCountry;
	}
 	public String getMatchProvi(){
		return this.matchProvi;
	}
	public void setMatchProvi(String matchProvi){
		this.matchProvi = matchProvi;
	}
 	public String getMatchZip(){
		return this.matchZip;
	}
	public void setMatchZip(String matchZip){
		this.matchZip = matchZip;
	}
 	public String getMxRes(){
		return this.mxRes;
	}
	public void setMxRes(String mxRes){
		this.mxRes = mxRes;
	}
 	public List<String> getTypes(){
		return this.types;
	}
	public void setTypes(List<String> types){
		this.types = types;
	}
}
