package com.ebuilder.asa;

import java.util.List;

public class DropOffParams{
   	private List<DropOffs> dropOffs;
   	private String mxRes;
   	private String useProxi;

 	public List<DropOffs> getDropOffs(){
		return this.dropOffs;
	}
	public void setDropOffs(List<DropOffs> dropOffs){
		this.dropOffs = dropOffs;
	}
 	public String getMxRes(){
		return this.mxRes;
	}
	public void setMxRes(String mxRes){
		this.mxRes = mxRes;
	}
 	public String getUseProxi(){
		return this.useProxi;
	}
	public void setUseProxi(String useProxi){
		this.useProxi = useProxi;
	}
}
