package com.ebuilder.asa;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
@JsonAutoDetect
public class Sloc implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -635826127405636785L;
	private String site;
   	private Addr addr;   	

 	public Addr getAddr(){
		return this.addr;
	}
	public void setAddr(Addr addr){
		this.addr = addr;
	}
 	public String getSite(){
		return this.site;
	}
	public void setSite(String site){
		this.site = site;
	}
}
