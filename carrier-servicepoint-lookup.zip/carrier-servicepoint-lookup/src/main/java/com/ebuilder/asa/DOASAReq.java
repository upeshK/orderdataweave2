package com.ebuilder.asa;

public class DOASAReq {
	private String msgid;
	private Sloc sloc;
	private DropOffParams dropOffParams;   	

 	public DropOffParams getDropOffParams(){
		return this.dropOffParams;
	}
	public void setDropOffParams(DropOffParams dropOffParams){
		this.dropOffParams = dropOffParams;
	}
 	public String getMsgid(){
		return this.msgid;
	}
	public void setMsgid(String msgid){
		this.msgid = msgid;
	}
 	public Sloc getSloc(){
		return this.sloc;
	}
	public void setSLoc(Sloc sloc){
		this.sloc = sloc;
	}
}
