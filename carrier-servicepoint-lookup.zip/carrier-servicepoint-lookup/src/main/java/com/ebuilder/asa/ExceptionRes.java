/**
 * 
 */
package com.ebuilder.asa;

import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;



/**
 * Copyright 2014, eBuilder AB
 * All rights reserved
 * <p/>
 * This is UNPUBLISHED PROPRIETARY SOURCE CODE
 * of eBuilder AB;
 * the contents of this file may not be disclosed to third parties,
 * copied or duplicated in any form, in whole or in part,
 * without the prior written permission of eBuilder AB.
 * <p/>
 * <p/>
 * Author :Upesh Kulatunge<br> 
 * Created: Oct 16, 2014<br>
 */

@JsonAutoDetect
@JsonSerialize(include = Inclusion.NON_NULL)
public class ExceptionRes {
	
	private String msgid;
	private List<Tr> tr;
	private Sloc sloc;
	public String getMsgid() {
		return msgid;
	}
	public void setMsgid(String msgid) {
		this.msgid = msgid;
	}
	public List<Tr> getTr() {
		return tr;
	}
	public void setTr(List<Tr> tr) {
		this.tr = tr;
	}
	public Sloc getSloc() {
		return sloc;
	}
	public void setSloc(Sloc sloc) {
		this.sloc = sloc;
	}
	
	
	
	
	
}
