package com.ebuilder.asa;

public class OpenHrs{   	
   	private String days;
   	private String open;
   	private String cls;

 	public String getCls(){
		return this.cls;
	}
	public void setCls(String cls){
		this.cls = cls;
	}
 	public String getDays(){
		return this.days;
	}
	public void setDays(String days){
		this.days = days;
	}
 	public String getOpen(){
		return this.open;
	}
	public void setOpen(String open){
		this.open = open;
	}
}
