package com.ebuilder.asa;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonAutoDetect
@JsonSerialize(include = Inclusion.NON_NULL)
public class Addr implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2786983389594130928L;
	private String name;
	private String line1;
   	private String line2;
   	private String line3;
   	private String zip;
   	private String city;
   	private String provi;
   	private String cn;
   	private String cc;

 	public String getCc(){
		return this.cc;
	}
	public void setCc(String cc){
		this.cc = cc;
	}
 	public String getCity(){
		return this.city;
	}
	public void setCity(String city){
		this.city = city;
	}
 	public String getCn(){
		return this.cn;
	}
	public void setCn(String cn){
		this.cn = cn;
	}
 	public String getLine1(){
		return this.line1;
	}
	public void setLine1(String line1){
		this.line1 = line1;
	}
 	public String getLine2(){
		return this.line2;
	}
	public void setLine2(String line2){
		this.line2 = line2;
	}
 	public String getLine3(){
		return this.line3;
	}
	public void setLine3(String line3){
		this.line3 = line3;
	}
 	public String getName(){
		return this.name;
	}
	public void setName(String name){
		this.name = name;
	}
 	public String getProvi(){
		return this.provi;
	}
	public void setProvi(String provi){
		this.provi = provi;
	}
 	public String getZip(){
		return this.zip;
	}
	public void setZip(String zip){
		this.zip = zip;
	}
}
