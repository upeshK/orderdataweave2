package com.ebuilder.asa;

import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
@JsonAutoDetect
@JsonSerialize(include = Inclusion.NON_NULL)
public class DOASARes {	
	private String msgid;
	@JsonDeserialize(as=Sloc.class, contentAs=Sloc.class)
	private Sloc sloc;
	private Gps gps;
	private List<DropOffs> dropoffs;   	
   	private List<Tr> tr;

 	public List<DropOffs> getDropoffs(){
		return this.dropoffs;
	}
	public void setDropoffs(List<DropOffs> dropoffs){
		this.dropoffs = dropoffs;
	}
 	public Gps getGps(){
		return this.gps;
	}
	public void setGps(Gps gps){
		this.gps = gps;
	}
 	public String getMsgid(){
		return this.msgid;
	}
	public void setMsgid(String msgid){
		this.msgid = msgid;
	}
 	public List<Tr> getTr(){
		return this.tr;
	}
	public void setTr(List<Tr> tr){
		this.tr = tr;
	}
	public Sloc getSloc() {
		return sloc;
	}
	public void setSloc(Sloc sloc) {
		this.sloc = sloc;
	}
 	
}
