@javax.xml.bind.annotation.XmlSchema(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ebuilder.carrier.dhl;
