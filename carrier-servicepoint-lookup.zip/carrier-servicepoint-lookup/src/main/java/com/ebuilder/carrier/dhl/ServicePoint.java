
package com.ebuilder.carrier.dhl;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ServicePoint complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServicePoint">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Identity" type="{http://DHL.ServicePoint.DataContracts/2008/10}ServicePointRef" minOccurs="0"/>
 *         &lt;element name="ServiceAddress" type="{http://DHL.ServicePoint.DataContracts/2008/10}ServiceAddress" minOccurs="0"/>
 *         &lt;element name="FeatureCodes" type="{http://DHL.ServicePoint.DataContracts/2008/10}FeatureCodeList" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServicePoint", propOrder = {
    "identity",
    "serviceAddress",
    "featureCodes"
})
public class ServicePoint {

    @XmlElementRef(name = "Identity", namespace = "http://DHL.ServicePoint.DataContracts/2008/10", type = JAXBElement.class, required = false)
    protected JAXBElement<ServicePointRef> identity;
    @XmlElementRef(name = "ServiceAddress", namespace = "http://DHL.ServicePoint.DataContracts/2008/10", type = JAXBElement.class, required = false)
    protected JAXBElement<ServiceAddress> serviceAddress;
    @XmlElementRef(name = "FeatureCodes", namespace = "http://DHL.ServicePoint.DataContracts/2008/10", type = JAXBElement.class, required = false)
    protected JAXBElement<FeatureCodeList> featureCodes;

    /**
     * Gets the value of the identity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ServicePointRef }{@code >}
     *     
     */
    public JAXBElement<ServicePointRef> getIdentity() {
        return identity;
    }

    /**
     * Sets the value of the identity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ServicePointRef }{@code >}
     *     
     */
    public void setIdentity(JAXBElement<ServicePointRef> value) {
        this.identity = value;
    }

    /**
     * Gets the value of the serviceAddress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ServiceAddress }{@code >}
     *     
     */
    public JAXBElement<ServiceAddress> getServiceAddress() {
        return serviceAddress;
    }

    /**
     * Sets the value of the serviceAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ServiceAddress }{@code >}
     *     
     */
    public void setServiceAddress(JAXBElement<ServiceAddress> value) {
        this.serviceAddress = value;
    }

    /**
     * Gets the value of the featureCodes property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link FeatureCodeList }{@code >}
     *     
     */
    public JAXBElement<FeatureCodeList> getFeatureCodes() {
        return featureCodes;
    }

    /**
     * Sets the value of the featureCodes property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link FeatureCodeList }{@code >}
     *     
     */
    public void setFeatureCodes(JAXBElement<FeatureCodeList> value) {
        this.featureCodes = value;
    }

}
