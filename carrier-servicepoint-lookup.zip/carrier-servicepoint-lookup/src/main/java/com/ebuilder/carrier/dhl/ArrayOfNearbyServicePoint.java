
package com.ebuilder.carrier.dhl;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ArrayOfNearbyServicePoint complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ArrayOfNearbyServicePoint">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="NearbyServicePoint" type="{http://DHL.ServicePoint.DataContracts/2008/10}NearbyServicePoint" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfNearbyServicePoint", propOrder = {
    "nearbyServicePoint"
})
public class ArrayOfNearbyServicePoint {

    @XmlElement(name = "NearbyServicePoint", nillable = true)
    protected List<NearbyServicePoint> nearbyServicePoint;

    /**
     * Gets the value of the nearbyServicePoint property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the nearbyServicePoint property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNearbyServicePoint().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NearbyServicePoint }
     * 
     * 
     */
    public List<NearbyServicePoint> getNearbyServicePoint() {
        if (nearbyServicePoint == null) {
            nearbyServicePoint = new ArrayList<NearbyServicePoint>();
        }
        return this.nearbyServicePoint;
    }

    /**
     * Sets the value of the nearbyServicePoint property.
     * 
     * @param nearbyServicePoint
     *     allowed object is
     *     {@link NearbyServicePoint }
     *     
     */
    public void setNearbyServicePoint(List<NearbyServicePoint> nearbyServicePoint) {
        this.nearbyServicePoint = nearbyServicePoint;
    }

}
