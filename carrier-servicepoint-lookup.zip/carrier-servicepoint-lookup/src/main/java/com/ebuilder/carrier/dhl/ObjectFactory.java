
package com.ebuilder.carrier.dhl;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ebuilder.carrier.dhl package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AnyURI_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "anyURI");
    private final static QName _Char_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "char");
    private final static QName _DateTime_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "dateTime");
    private final static QName _BitCatCodeList_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "BitCatCodeList");
    private final static QName _QName_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "QName");
    private final static QName _NearbyServicePoint_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "NearbyServicePoint");
    private final static QName _UnsignedShort_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedShort");
    private final static QName _Float_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "float");
    private final static QName _Long_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "long");
    private final static QName _FeatureCodeList_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "FeatureCodeList");
    private final static QName _Short_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "short");
    private final static QName _Base64Binary_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "base64Binary");
    private final static QName _Byte_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "byte");
    private final static QName _ServiceAddress_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "ServiceAddress");
    private final static QName _Boolean_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "boolean");
    private final static QName _ServicePointRef_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "ServicePointRef");
    private final static QName _UnsignedByte_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedByte");
    private final static QName _AnyType_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "anyType");
    private final static QName _UnsignedInt_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedInt");
    private final static QName _Int_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "int");
    private final static QName _Decimal_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "decimal");
    private final static QName _ServicePoint_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "ServicePoint");
    private final static QName _PhysicalAddress_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "PhysicalAddress");
    private final static QName _Double_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "double");
    private final static QName _ArrayOfNearbyServicePoint_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "ArrayOfNearbyServicePoint");
    private final static QName _Guid_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "guid");
    private final static QName _Duration_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "duration");
    private final static QName _String_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "string");
    private final static QName _UnsignedLong_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedLong");
    private final static QName _TelecomInfo_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "TelecomInfo");
    private final static QName _ServicePointFeatureCodes_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "FeatureCodes");
    private final static QName _ServicePointIdentity_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "Identity");
    private final static QName _TelecomInfoFax_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "Fax");
    private final static QName _TelecomInfoEmail_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "Email");
    private final static QName _TelecomInfoPhone_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "Phone");
    private final static QName _NearbyServicePointCity_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "City");
    private final static QName _NearbyServicePointPostCode_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "PostCode");
    private final static QName _NearbyServicePointStreetName_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "StreetName");
    private final static QName _ServiceAddressContactPersonName_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "ContactPersonName");
    private final static QName _ServiceAddressAddress_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "Address");
    private final static QName _ServiceAddressTelecom_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "Telecom");
    private final static QName _GetNearestServicePointsResponseServicePoints_QNAME = new QName("http://DHL.ServicePoint.ServiceContracts/2008/10", "ServicePoints");
    private final static QName _GetServicePointDetailResponseServicePointDetail_QNAME = new QName("http://DHL.ServicePoint.ServiceContracts/2008/10", "ServicePointDetail");
    private final static QName _GetNearestServicePointsRequestFeatureCodes_QNAME = new QName("http://DHL.ServicePoint.ServiceContracts/2008/10", "FeatureCodes");
    private final static QName _GetNearestServicePointsRequestCountryCode_QNAME = new QName("http://DHL.ServicePoint.ServiceContracts/2008/10", "CountryCode");
    private final static QName _GetNearestServicePointsRequestBitCatCodes_QNAME = new QName("http://DHL.ServicePoint.ServiceContracts/2008/10", "BitCatCodes");
    private final static QName _GetNearestServicePointsRequestCity_QNAME = new QName("http://DHL.ServicePoint.ServiceContracts/2008/10", "City");
    private final static QName _GetNearestServicePointsRequestStreet_QNAME = new QName("http://DHL.ServicePoint.ServiceContracts/2008/10", "Street");
    private final static QName _GetNearestServicePointsRequestPostCode_QNAME = new QName("http://DHL.ServicePoint.ServiceContracts/2008/10", "PostCode");
    private final static QName _PhysicalAddressStreet2_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "Street2");
    private final static QName _PhysicalAddressStreet1_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "Street1");
    private final static QName _PhysicalAddressCountryCode_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "CountryCode");
    private final static QName _PhysicalAddressAddresseeName_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "AddresseeName");
    private final static QName _ServicePointRefDisplayName_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "DisplayName");
    private final static QName _ServicePointRefId_QNAME = new QName("http://DHL.ServicePoint.DataContracts/2008/10", "Id");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ebuilder.carrier.dhl
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetServicePointDetailRequest }
     * 
     */
    public GetServicePointDetailRequest createGetServicePointDetailRequest() {
        return new GetServicePointDetailRequest();
    }

    /**
     * Create an instance of {@link ServicePointRef }
     * 
     */
    public ServicePointRef createServicePointRef() {
        return new ServicePointRef();
    }

    /**
     * Create an instance of {@link GetServicePointDetailResponse }
     * 
     */
    public GetServicePointDetailResponse createGetServicePointDetailResponse() {
        return new GetServicePointDetailResponse();
    }

    /**
     * Create an instance of {@link ServicePoint }
     * 
     */
    public ServicePoint createServicePoint() {
        return new ServicePoint();
    }

    /**
     * Create an instance of {@link GetNearestServicePointsRequest }
     * 
     */
    public GetNearestServicePointsRequest createGetNearestServicePointsRequest() {
        return new GetNearestServicePointsRequest();
    }

    /**
     * Create an instance of {@link FeatureCodeList }
     * 
     */
    public FeatureCodeList createFeatureCodeList() {
        return new FeatureCodeList();
    }

    /**
     * Create an instance of {@link BitCatCodeList }
     * 
     */
    public BitCatCodeList createBitCatCodeList() {
        return new BitCatCodeList();
    }

    /**
     * Create an instance of {@link GetNearestServicePointsResponse }
     * 
     */
    public GetNearestServicePointsResponse createGetNearestServicePointsResponse() {
        return new GetNearestServicePointsResponse();
    }

    /**
     * Create an instance of {@link ArrayOfNearbyServicePoint }
     * 
     */
    public ArrayOfNearbyServicePoint createArrayOfNearbyServicePoint() {
        return new ArrayOfNearbyServicePoint();
    }

    /**
     * Create an instance of {@link PhysicalAddress }
     * 
     */
    public PhysicalAddress createPhysicalAddress() {
        return new PhysicalAddress();
    }

    /**
     * Create an instance of {@link TelecomInfo }
     * 
     */
    public TelecomInfo createTelecomInfo() {
        return new TelecomInfo();
    }

    /**
     * Create an instance of {@link NearbyServicePoint }
     * 
     */
    public NearbyServicePoint createNearbyServicePoint() {
        return new NearbyServicePoint();
    }

    /**
     * Create an instance of {@link ServiceAddress }
     * 
     */
    public ServiceAddress createServiceAddress() {
        return new ServiceAddress();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "anyURI")
    public JAXBElement<String> createAnyURI(String value) {
        return new JAXBElement<String>(_AnyURI_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "char")
    public JAXBElement<Integer> createChar(Integer value) {
        return new JAXBElement<Integer>(_Char_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "dateTime")
    public JAXBElement<XMLGregorianCalendar> createDateTime(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_DateTime_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BitCatCodeList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "BitCatCodeList")
    public JAXBElement<BitCatCodeList> createBitCatCodeList(BitCatCodeList value) {
        return new JAXBElement<BitCatCodeList>(_BitCatCodeList_QNAME, BitCatCodeList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "QName")
    public JAXBElement<QName> createQName(QName value) {
        return new JAXBElement<QName>(_QName_QNAME, QName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NearbyServicePoint }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "NearbyServicePoint")
    public JAXBElement<NearbyServicePoint> createNearbyServicePoint(NearbyServicePoint value) {
        return new JAXBElement<NearbyServicePoint>(_NearbyServicePoint_QNAME, NearbyServicePoint.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedShort")
    public JAXBElement<Integer> createUnsignedShort(Integer value) {
        return new JAXBElement<Integer>(_UnsignedShort_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Float }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "float")
    public JAXBElement<Float> createFloat(Float value) {
        return new JAXBElement<Float>(_Float_QNAME, Float.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "long")
    public JAXBElement<Long> createLong(Long value) {
        return new JAXBElement<Long>(_Long_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FeatureCodeList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "FeatureCodeList")
    public JAXBElement<FeatureCodeList> createFeatureCodeList(FeatureCodeList value) {
        return new JAXBElement<FeatureCodeList>(_FeatureCodeList_QNAME, FeatureCodeList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Short }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "short")
    public JAXBElement<Short> createShort(Short value) {
        return new JAXBElement<Short>(_Short_QNAME, Short.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link byte[]}{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "base64Binary")
    public JAXBElement<byte[]> createBase64Binary(byte[] value) {
        return new JAXBElement<byte[]>(_Base64Binary_QNAME, byte[].class, null, ((byte[]) value));
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Byte }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "byte")
    public JAXBElement<Byte> createByte(Byte value) {
        return new JAXBElement<Byte>(_Byte_QNAME, Byte.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ServiceAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "ServiceAddress")
    public JAXBElement<ServiceAddress> createServiceAddress(ServiceAddress value) {
        return new JAXBElement<ServiceAddress>(_ServiceAddress_QNAME, ServiceAddress.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "boolean")
    public JAXBElement<Boolean> createBoolean(Boolean value) {
        return new JAXBElement<Boolean>(_Boolean_QNAME, Boolean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ServicePointRef }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "ServicePointRef")
    public JAXBElement<ServicePointRef> createServicePointRef(ServicePointRef value) {
        return new JAXBElement<ServicePointRef>(_ServicePointRef_QNAME, ServicePointRef.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Short }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedByte")
    public JAXBElement<Short> createUnsignedByte(Short value) {
        return new JAXBElement<Short>(_UnsignedByte_QNAME, Short.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "anyType")
    public JAXBElement<Object> createAnyType(Object value) {
        return new JAXBElement<Object>(_AnyType_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedInt")
    public JAXBElement<Long> createUnsignedInt(Long value) {
        return new JAXBElement<Long>(_UnsignedInt_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "int")
    public JAXBElement<Integer> createInt(Integer value) {
        return new JAXBElement<Integer>(_Int_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "decimal")
    public JAXBElement<BigDecimal> createDecimal(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_Decimal_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ServicePoint }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "ServicePoint")
    public JAXBElement<ServicePoint> createServicePoint(ServicePoint value) {
        return new JAXBElement<ServicePoint>(_ServicePoint_QNAME, ServicePoint.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PhysicalAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "PhysicalAddress")
    public JAXBElement<PhysicalAddress> createPhysicalAddress(PhysicalAddress value) {
        return new JAXBElement<PhysicalAddress>(_PhysicalAddress_QNAME, PhysicalAddress.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "double")
    public JAXBElement<Double> createDouble(Double value) {
        return new JAXBElement<Double>(_Double_QNAME, Double.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfNearbyServicePoint }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "ArrayOfNearbyServicePoint")
    public JAXBElement<ArrayOfNearbyServicePoint> createArrayOfNearbyServicePoint(ArrayOfNearbyServicePoint value) {
        return new JAXBElement<ArrayOfNearbyServicePoint>(_ArrayOfNearbyServicePoint_QNAME, ArrayOfNearbyServicePoint.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "guid")
    public JAXBElement<String> createGuid(String value) {
        return new JAXBElement<String>(_Guid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Duration }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "duration")
    public JAXBElement<Duration> createDuration(Duration value) {
        return new JAXBElement<Duration>(_Duration_QNAME, Duration.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "string")
    public JAXBElement<String> createString(String value) {
        return new JAXBElement<String>(_String_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedLong")
    public JAXBElement<BigInteger> createUnsignedLong(BigInteger value) {
        return new JAXBElement<BigInteger>(_UnsignedLong_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TelecomInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "TelecomInfo")
    public JAXBElement<TelecomInfo> createTelecomInfo(TelecomInfo value) {
        return new JAXBElement<TelecomInfo>(_TelecomInfo_QNAME, TelecomInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FeatureCodeList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "FeatureCodes", scope = ServicePoint.class)
    public JAXBElement<FeatureCodeList> createServicePointFeatureCodes(FeatureCodeList value) {
        return new JAXBElement<FeatureCodeList>(_ServicePointFeatureCodes_QNAME, FeatureCodeList.class, ServicePoint.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ServiceAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "ServiceAddress", scope = ServicePoint.class)
    public JAXBElement<ServiceAddress> createServicePointServiceAddress(ServiceAddress value) {
        return new JAXBElement<ServiceAddress>(_ServiceAddress_QNAME, ServiceAddress.class, ServicePoint.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ServicePointRef }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "Identity", scope = ServicePoint.class)
    public JAXBElement<ServicePointRef> createServicePointIdentity(ServicePointRef value) {
        return new JAXBElement<ServicePointRef>(_ServicePointIdentity_QNAME, ServicePointRef.class, ServicePoint.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "Fax", scope = TelecomInfo.class)
    public JAXBElement<String> createTelecomInfoFax(String value) {
        return new JAXBElement<String>(_TelecomInfoFax_QNAME, String.class, TelecomInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "Email", scope = TelecomInfo.class)
    public JAXBElement<String> createTelecomInfoEmail(String value) {
        return new JAXBElement<String>(_TelecomInfoEmail_QNAME, String.class, TelecomInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "Phone", scope = TelecomInfo.class)
    public JAXBElement<String> createTelecomInfoPhone(String value) {
        return new JAXBElement<String>(_TelecomInfoPhone_QNAME, String.class, TelecomInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "City", scope = NearbyServicePoint.class)
    public JAXBElement<String> createNearbyServicePointCity(String value) {
        return new JAXBElement<String>(_NearbyServicePointCity_QNAME, String.class, NearbyServicePoint.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FeatureCodeList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "FeatureCodes", scope = NearbyServicePoint.class)
    public JAXBElement<FeatureCodeList> createNearbyServicePointFeatureCodes(FeatureCodeList value) {
        return new JAXBElement<FeatureCodeList>(_ServicePointFeatureCodes_QNAME, FeatureCodeList.class, NearbyServicePoint.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "PostCode", scope = NearbyServicePoint.class)
    public JAXBElement<String> createNearbyServicePointPostCode(String value) {
        return new JAXBElement<String>(_NearbyServicePointPostCode_QNAME, String.class, NearbyServicePoint.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "StreetName", scope = NearbyServicePoint.class)
    public JAXBElement<String> createNearbyServicePointStreetName(String value) {
        return new JAXBElement<String>(_NearbyServicePointStreetName_QNAME, String.class, NearbyServicePoint.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ServicePointRef }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "Identity", scope = NearbyServicePoint.class)
    public JAXBElement<ServicePointRef> createNearbyServicePointIdentity(ServicePointRef value) {
        return new JAXBElement<ServicePointRef>(_ServicePointIdentity_QNAME, ServicePointRef.class, NearbyServicePoint.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "ContactPersonName", scope = ServiceAddress.class)
    public JAXBElement<String> createServiceAddressContactPersonName(String value) {
        return new JAXBElement<String>(_ServiceAddressContactPersonName_QNAME, String.class, ServiceAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PhysicalAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "Address", scope = ServiceAddress.class)
    public JAXBElement<PhysicalAddress> createServiceAddressAddress(PhysicalAddress value) {
        return new JAXBElement<PhysicalAddress>(_ServiceAddressAddress_QNAME, PhysicalAddress.class, ServiceAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TelecomInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "Telecom", scope = ServiceAddress.class)
    public JAXBElement<TelecomInfo> createServiceAddressTelecom(TelecomInfo value) {
        return new JAXBElement<TelecomInfo>(_ServiceAddressTelecom_QNAME, TelecomInfo.class, ServiceAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfNearbyServicePoint }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.ServiceContracts/2008/10", name = "ServicePoints", scope = GetNearestServicePointsResponse.class)
    public JAXBElement<ArrayOfNearbyServicePoint> createGetNearestServicePointsResponseServicePoints(ArrayOfNearbyServicePoint value) {
        return new JAXBElement<ArrayOfNearbyServicePoint>(_GetNearestServicePointsResponseServicePoints_QNAME, ArrayOfNearbyServicePoint.class, GetNearestServicePointsResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ServicePoint }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.ServiceContracts/2008/10", name = "ServicePointDetail", scope = GetServicePointDetailResponse.class)
    public JAXBElement<ServicePoint> createGetServicePointDetailResponseServicePointDetail(ServicePoint value) {
        return new JAXBElement<ServicePoint>(_GetServicePointDetailResponseServicePointDetail_QNAME, ServicePoint.class, GetServicePointDetailResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FeatureCodeList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.ServiceContracts/2008/10", name = "FeatureCodes", scope = GetNearestServicePointsRequest.class)
    public JAXBElement<FeatureCodeList> createGetNearestServicePointsRequestFeatureCodes(FeatureCodeList value) {
        return new JAXBElement<FeatureCodeList>(_GetNearestServicePointsRequestFeatureCodes_QNAME, FeatureCodeList.class, GetNearestServicePointsRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.ServiceContracts/2008/10", name = "CountryCode", scope = GetNearestServicePointsRequest.class)
    public JAXBElement<String> createGetNearestServicePointsRequestCountryCode(String value) {
        return new JAXBElement<String>(_GetNearestServicePointsRequestCountryCode_QNAME, String.class, GetNearestServicePointsRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BitCatCodeList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.ServiceContracts/2008/10", name = "BitCatCodes", scope = GetNearestServicePointsRequest.class)
    public JAXBElement<BitCatCodeList> createGetNearestServicePointsRequestBitCatCodes(BitCatCodeList value) {
        return new JAXBElement<BitCatCodeList>(_GetNearestServicePointsRequestBitCatCodes_QNAME, BitCatCodeList.class, GetNearestServicePointsRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.ServiceContracts/2008/10", name = "City", scope = GetNearestServicePointsRequest.class)
    public JAXBElement<String> createGetNearestServicePointsRequestCity(String value) {
        return new JAXBElement<String>(_GetNearestServicePointsRequestCity_QNAME, String.class, GetNearestServicePointsRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.ServiceContracts/2008/10", name = "Street", scope = GetNearestServicePointsRequest.class)
    public JAXBElement<String> createGetNearestServicePointsRequestStreet(String value) {
        return new JAXBElement<String>(_GetNearestServicePointsRequestStreet_QNAME, String.class, GetNearestServicePointsRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.ServiceContracts/2008/10", name = "PostCode", scope = GetNearestServicePointsRequest.class)
    public JAXBElement<String> createGetNearestServicePointsRequestPostCode(String value) {
        return new JAXBElement<String>(_GetNearestServicePointsRequestPostCode_QNAME, String.class, GetNearestServicePointsRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "City", scope = PhysicalAddress.class)
    public JAXBElement<String> createPhysicalAddressCity(String value) {
        return new JAXBElement<String>(_NearbyServicePointCity_QNAME, String.class, PhysicalAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "Street2", scope = PhysicalAddress.class)
    public JAXBElement<String> createPhysicalAddressStreet2(String value) {
        return new JAXBElement<String>(_PhysicalAddressStreet2_QNAME, String.class, PhysicalAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "Street1", scope = PhysicalAddress.class)
    public JAXBElement<String> createPhysicalAddressStreet1(String value) {
        return new JAXBElement<String>(_PhysicalAddressStreet1_QNAME, String.class, PhysicalAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "CountryCode", scope = PhysicalAddress.class)
    public JAXBElement<String> createPhysicalAddressCountryCode(String value) {
        return new JAXBElement<String>(_PhysicalAddressCountryCode_QNAME, String.class, PhysicalAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "AddresseeName", scope = PhysicalAddress.class)
    public JAXBElement<String> createPhysicalAddressAddresseeName(String value) {
        return new JAXBElement<String>(_PhysicalAddressAddresseeName_QNAME, String.class, PhysicalAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "PostCode", scope = PhysicalAddress.class)
    public JAXBElement<String> createPhysicalAddressPostCode(String value) {
        return new JAXBElement<String>(_NearbyServicePointPostCode_QNAME, String.class, PhysicalAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "DisplayName", scope = ServicePointRef.class)
    public JAXBElement<String> createServicePointRefDisplayName(String value) {
        return new JAXBElement<String>(_ServicePointRefDisplayName_QNAME, String.class, ServicePointRef.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://DHL.ServicePoint.DataContracts/2008/10", name = "Id", scope = ServicePointRef.class)
    public JAXBElement<String> createServicePointRefId(String value) {
        return new JAXBElement<String>(_ServicePointRefId_QNAME, String.class, ServicePointRef.class, value);
    }

}
