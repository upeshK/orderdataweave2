
package com.ebuilder.carrier.dhl;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ServiceAddress complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServiceAddress">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ContactPersonName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Address" type="{http://DHL.ServicePoint.DataContracts/2008/10}PhysicalAddress" minOccurs="0"/>
 *         &lt;element name="Telecom" type="{http://DHL.ServicePoint.DataContracts/2008/10}TelecomInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServiceAddress", propOrder = {
    "contactPersonName",
    "address",
    "telecom"
})
public class ServiceAddress {

    @XmlElementRef(name = "ContactPersonName", namespace = "http://DHL.ServicePoint.DataContracts/2008/10", type = JAXBElement.class, required = false)
    protected JAXBElement<String> contactPersonName;
    @XmlElementRef(name = "Address", namespace = "http://DHL.ServicePoint.DataContracts/2008/10", type = JAXBElement.class, required = false)
    protected JAXBElement<PhysicalAddress> address;
    @XmlElementRef(name = "Telecom", namespace = "http://DHL.ServicePoint.DataContracts/2008/10", type = JAXBElement.class, required = false)
    protected JAXBElement<TelecomInfo> telecom;

    /**
     * Gets the value of the contactPersonName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getContactPersonName() {
        return contactPersonName;
    }

    /**
     * Sets the value of the contactPersonName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setContactPersonName(JAXBElement<String> value) {
        this.contactPersonName = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PhysicalAddress }{@code >}
     *     
     */
    public JAXBElement<PhysicalAddress> getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PhysicalAddress }{@code >}
     *     
     */
    public void setAddress(JAXBElement<PhysicalAddress> value) {
        this.address = value;
    }

    /**
     * Gets the value of the telecom property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link TelecomInfo }{@code >}
     *     
     */
    public JAXBElement<TelecomInfo> getTelecom() {
        return telecom;
    }

    /**
     * Sets the value of the telecom property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link TelecomInfo }{@code >}
     *     
     */
    public void setTelecom(JAXBElement<TelecomInfo> value) {
        this.telecom = value;
    }

}
