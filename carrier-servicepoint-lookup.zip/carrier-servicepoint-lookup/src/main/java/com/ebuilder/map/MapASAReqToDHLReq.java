package com.ebuilder.map;

import java.util.List;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.MuleSession;
import org.mule.api.lifecycle.Callable;
import org.mule.api.transport.PropertyScope;

import com.ebuilder.asa.Addr;
import com.ebuilder.asa.DOASAReq;
import com.ebuilder.asa.DropOffParams;
import com.ebuilder.asa.DropOffs;
//import com.ebuilder.asa.Gps;
import com.ebuilder.asa.Sloc;
import com.ebuilder.carrier.dhl.GetNearestServicePointsRequest;
import com.ebuilder.carrier.dhl.ObjectFactory;

public class MapASAReqToDHLReq implements Callable {
	@Override
	public GetNearestServicePointsRequest onCall(MuleEventContext eventContext)
			throws Exception {
		MuleMessage msg = eventContext.getMessage();
		//MuleSession muleSession = eventContext.getSession();
		DOASAReq doASAReq = (DOASAReq) msg.getPayload();

		GetNearestServicePointsRequest gnspr = new GetNearestServicePointsRequest();// Customer

		Sloc slASA = null;// ASA
		Addr addrASA = null;// ASA
		// Gps gpsASAOut = null;//ASA
		DropOffParams dopASA = null;// ASA
		List<DropOffs> doASAList = null;// ASA
		DropOffs doASA = null; // ASA

		slASA = doASAReq.getSloc();
		ObjectFactory factory=new ObjectFactory();

		if (null != slASA) {
			addrASA = slASA.getAddr();
			if (null != addrASA) {
				gnspr.setCountryCode(factory.createGetNearestServicePointsRequestCountryCode(addrASA.getCc()));
				gnspr.setStreet(factory.createGetNearestServicePointsRequestStreet(addrASA.getLine1()));
				gnspr.setPostCode(factory.createGetNearestServicePointsRequestPostCode(addrASA.getZip()));
				gnspr.setCity(factory.createGetNearestServicePointsRequestCity(addrASA.getCity()));
			}

		}

		dopASA = doASAReq.getDropOffParams();
		if (null != dopASA) {
			doASAList = dopASA.getDropOffs();
			if (null != doASAList && !doASAList.isEmpty()) {
				doASA = doASAList.get(0);
			}

		}

		gnspr.setMaxNumberOfItems(null != doASA ? Integer.parseInt(doASA
				.getMxRes()) : null);

		// muleSession.setProperty("cc", null!=addrASA?addrASA.getCc():null);
		msg.setProperty("exurl",
				(null != doASA && null != doASA.getExURL()) ? doASA.getExURL()
						.replaceAll("https://", "") : null,
				PropertyScope.OUTBOUND);
		// muleSession.setProperty("msgid", doASAReq.getMsgid());
		// muleSession.setProperty("sloc", slASA);
		// muleSession.setProperty("lookupSRC",
		// null!=doASA?doASA.getLookupSRC():null);
		// eventContext.getSession().setProperty("requestMsgRef",
		// msg.getUniqueId());

		msg.setProperty("cc", null != addrASA ? addrASA.getCc() : null,
				PropertyScope.SESSION);
		msg.setProperty("msgid", doASAReq.getMsgid(), PropertyScope.SESSION);
		msg.setProperty("sloc", slASA, PropertyScope.SESSION);
		msg.setProperty("lookupSRC", null != doASA ? doASA.getLookupSRC()
				: null, PropertyScope.SESSION);
		msg.setProperty("requestMsgRef", msg.getUniqueId(),
				PropertyScope.SESSION);

		return gnspr;

	}
}
