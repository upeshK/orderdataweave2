package com.ebuilder.map;

import java.util.ArrayList;
import java.util.List;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.MuleSession;
import org.mule.api.lifecycle.Callable;

import com.ebuilder.asa.Addr;
import com.ebuilder.asa.DOASARes;
import com.ebuilder.asa.DropOffs;
import com.ebuilder.asa.Sloc;
import com.ebuilder.asa.Tr;
import com.ebuilder.carrier.dhl.ArrayOfNearbyServicePoint;
import com.ebuilder.carrier.dhl.GetNearestServicePointsResponse;
import com.ebuilder.carrier.dhl.NearbyServicePoint;
import com.ebuilder.carrier.dhl.ServicePointRef;

public class MapDHLResToASARes implements Callable {
	@Override
	public DOASARes onCall(MuleEventContext eventContext) throws Exception {
		MuleMessage msg = eventContext.getMessage();
		MuleSession muleSession = eventContext.getSession();
		//System.out.println("exceptionMessageTest"+eventContext.getMessage().getExceptionPayload());
		
		
		DOASARes doASARes = new DOASARes();//ASA
		/*String msgid = msg.getProperty("msgid", PropertyScope.OUTBOUND);//ASA
		
		Sloc slocASA = msg.getProperty("sloc", PropertyScope.OUTBOUND);//ASA
		String cc = msg.getProperty("cc", PropertyScope.OUTBOUND);//ASA
		String type = msg.getProperty("lookupSRC", PropertyScope.OUTBOUND);//ASA*/
		//Addr addrASAOut = new Addr();//ASA
		
		String msgid = muleSession.getProperty("msgid");
		Sloc slocASA = muleSession.getProperty("sloc");
		String cc =	muleSession.getProperty("cc");	
		String type = muleSession.getProperty("lookupSRC");
		
		
		
		if(eventContext.getMessage().getExceptionPayload() == null){
			
			GetNearestServicePointsResponse servicePointDHLRes = (GetNearestServicePointsResponse)msg.getPayload();
			
			//ArrayOfNearbyServicePoint arrayOfNearByServPointsCarrier = null;//Carrier
			//List<NearbyServicePoint> nearByServPointsListCarrier = null;//Carrier
			
			if(null!=servicePointDHLRes && null!=servicePointDHLRes.getServicePoints()){
				ArrayOfNearbyServicePoint arrayOfNearByServPointsCarrier = servicePointDHLRes.getServicePoints().getValue();
				
				if(null!=arrayOfNearByServPointsCarrier){
					List<NearbyServicePoint> nearByServPointsListCarrier = arrayOfNearByServPointsCarrier.getNearbyServicePoint();
					if(null!=nearByServPointsListCarrier && !nearByServPointsListCarrier.isEmpty()){
						List<DropOffs> doASAList = new ArrayList<DropOffs>();
						for(NearbyServicePoint nearByServPoint: nearByServPointsListCarrier){
							if(null!=nearByServPoint){
								DropOffs doASA = new DropOffs();
								Addr addrASAin = new Addr();
								if(null!=nearByServPoint.getIdentity()){
									ServicePointRef serPointRef = nearByServPoint.getIdentity().getValue();//customer
									if(null!=serPointRef.getId()){
										doASA.setSite(serPointRef.getId().getValue());
									}
									if(null!=serPointRef.getDisplayName()){
										addrASAin.setName(serPointRef.getDisplayName().getValue());
									}
									
								}
								if(null!=nearByServPoint.getStreetName()){
									addrASAin.setLine1(nearByServPoint.getStreetName().getValue());
								}
								if(null!=nearByServPoint.getPostCode()){
									addrASAin.setZip(nearByServPoint.getPostCode().getValue());
								}
								if(null!=nearByServPoint.getCity()){
									addrASAin.setCity(nearByServPoint.getCity().getValue());
								}	
								
								addrASAin.setCc(cc);
								doASA.setType(type);
								//doASA.setSite(serPointRef.getId());
								doASA.setAddr(addrASAin);
								//doASA.setProxi(null!=nearByServPoint.getRouteDistance()?nearByServPoint.getRouteDistance().toString():null);
								doASA.setProxi(null!=nearByServPoint.getDistance()?nearByServPoint.getDistance().toString():null);
								doASAList.add(doASA);
							}
							
						}
						doASARes.setDropoffs(doASAList);
					}
					
					
					
				}
				
			}
			
			/*Tr tr=new Tr();
			tr.setRc("0");
			tr.setRt("SUCCESS");
			tr.setRd("SUCCESS");
			
			List<Tr> trList= new ArrayList<Tr>();
			trList.add(tr);
			doASARes.setTr(trList);*/
		} else {
			Tr tr=new Tr();
			tr.setRc("1");
			tr.setRt("ERROR");
			tr.setRd(msg.getExceptionPayload().getRootException().toString());
			System.out.println("exceptionMessageTestError"+eventContext.getMessage().getExceptionPayload().getRootException().toString());
			List<Tr> trList= new ArrayList<Tr>();
			trList.add(tr);
			doASARes.setTr(trList);
		}
		
		doASARes.setMsgid(msgid);
		doASARes.setSloc(slocASA);	
		
		//System.out.println(">>>>>>>>>>>>>>>>>>>>"+eventContext.getSession().getProperty("requestMsgRef"));
		System.out.println("ResponseMsgRef"+ msg.getUniqueId());
		
		return doASARes;
	}
	
}
